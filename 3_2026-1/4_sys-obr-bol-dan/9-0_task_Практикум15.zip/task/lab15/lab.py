"""Практическая работа 15. Локальный пакетный расчёт, стандартная библиотека."""
import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "results"
FIELDS = "event_id event_time arrival_time event_type status amount".split()
TOTAL = ["window", "purchases", "cents"]
HASHES = {
    "events.csv": "4b2e96b86f774b59682edb3ed876a8f46170a5a090f4e37468d4a3bba42243af",
    "reference.csv": "b97942a8d134ff66554fac51b16f2236f3420cecf804a25fcb72c1185971f4cc",
}
PRODUCTS = ["journal.csv", "partials.csv", "totals.csv"]
REPORT_FIELDS = ["Автор", "Вариант", "Паспорт", "Ручной расчёт", "Баланс", "Частичные итоги", "Повтор", "Прогноз до fault", "Сверка", "Ограничение", "Порядок запуска"]


def write(path, text):
    path.parent.mkdir(exist_ok=True, parents=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_bytes(text.encode("utf-8"))
    temp.replace(path)


def write_csv(path, fields, rows):
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(fields)
    writer.writerows(rows)
    write(path, buffer.getvalue())


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_sources():
    for name, expected in HASHES.items():
        if digest(DATA / name) != expected:
            raise ValueError("Source changed: " + name + ". Extract the original ZIP again.")


def valid(r):
    if not re.fullmatch(r"E\d{3}", r["event_id"]):
        return False
    try:
        for col in ("event_time", "arrival_time"):
            datetime.strptime(r[col], "%H:%M:%S")
    except ValueError:
        return False
    return (r["event_type"] in ("purchase", "view") and r["status"] in ("success", "failed")
            and bool(re.fullmatch(r"\d+\.\d{2}", r["amount"])))


def calculate(batch_size, dest):
    seen, journal = {}, []
    parts = defaultdict(lambda: [0, 0])
    rows = read_csv(DATA / "events.csv")
    for index, row in enumerate(rows):
        batch = index // batch_size + 1
        eid = row["event_id"]
        window = ""
        if not valid(row):
            decision = "INVALID"
        elif eid in seen:
            if seen[eid] != row:
                raise ValueError("Conflicting event: " + eid)
            decision = "DUPLICATE"
        else:
            seen[eid] = row
            if (row["event_type"], row["status"]) != ("purchase", "success"):
                decision = "FILTERED"
            else:
                decision = "ACCEPT"
                hour, minute, _ = map(int, row["event_time"].split(":"))
                window = f"{hour:02}:{minute // 5 * 5:02}"
                unit = parts[batch, window]
                unit[0] += 1
                unit[1] += int(row["amount"].replace(".", ""))
        journal.append((index + 1, batch, eid, decision, window))
    totals = defaultdict(lambda: [0, 0])
    for (_, window), (count, cents) in parts.items():
        totals[window][0] += count
        totals[window][1] += cents
    write_csv(dest / "journal.csv", ["row","batch","event_id","decision","window"], journal)
    write_csv(dest / "partials.csv", ["batch", *TOTAL], [(b, w, *v) for (b,w),v in sorted(parts.items())])
    write_csv(dest / "totals.csv", TOTAL, [(w, *v) for w,v in sorted(totals.items())])
    return Counter(row[3] for row in journal)


def reference():
    # Независимый прямой SQL по исходным 12 событиям до внесения учебных дефектов.
    with sqlite3.connect(":memory:") as db:
        db.execute("create table events (id, t, kind, status, amount)")
        db.executemany("insert into events values (?,?,?,?,?)", [
            tuple(r[k] for k in ("event_id","event_time","event_type","status","amount"))
            for r in read_csv(DATA / "reference.csv")])
        return db.execute("""select strftime('%H:',t) || printf('%02d',cast(strftime('%M',t) as integer)/5*5),
                              count(*), sum(cast(round(cast(amount as numeric)*100) as integer))
                              from events where kind='purchase' and status='success'
                              group by 1 order by 1""").fetchall()


def audit(path):
    rows = read_csv(path)
    if rows and list(rows[0]) != TOTAL:
        raise ValueError("Wrong result schema")
    actual = [(r["window"], int(r["purchases"]), int(r["cents"])) for r in rows]
    expected = reference()
    lines = ["window  actual(n,cents)  reference(n,cents)"]
    for key in sorted({r[0] for r in actual + expected}):
        a = [r[1:] for r in actual if r[0] == key]
        e = [r[1:] for r in expected if r[0] == key]
        lines.append(f"{key}  {a}  {e}  {'OK' if a == e else 'DIFF'}")
    ok = sorted(actual) == expected
    lines.append("audit=" + ("PASS" if ok else "BLOCK"))
    return ok, "\n".join(lines)


def run(action):
    checked_sources()
    if action == "check":
        return ("Python OK | lab=15.2\nevents.csv rows=14 | reference.csv rows=12\n"
                "sha256=OK | encoding=UTF-8\nevents_sha256=" + HASHES["events.csv"])
    if action in ("start3", "start4"):
        size = int(action[-1])
        if (OUT / "config.json").exists() and json.loads((OUT / "config.json").read_text())["batch_size"] != size:
            raise ValueError("Different variant. Use a fresh project folder.")
        write(OUT / "config.json", json.dumps({"version":"15.2","batch_size":size,"window_minutes":5,
            "mode":"batch","python":sys.version.split()[0],"source_sha256":HASHES["events.csv"]}, indent=2))
        counts = calculate(size, OUT)
        return (f"batch_size={size} | batches={(14+size-1)//size}\n"
                f"ACCEPT={counts['ACCEPT']} FILTERED={counts['FILTERED']} "
                f"DUPLICATE={counts['DUPLICATE']} INVALID={counts['INVALID']}\nsaved=results/totals.csv")
    size = json.loads((OUT / "config.json").read_text())["batch_size"]
    if action == "repeat":
        with TemporaryDirectory() as tmp:
            target = Path(tmp)
            calculate(size, target)
            same = all((OUT / n).read_bytes() == (target / n).read_bytes() for n in PRODUCTS)
        msg = f"batch_size={size} | files_compared=3\nrepeat=" + ("IDENTICAL" if same else "DIFF")
        write(OUT / "repeat.txt", msg+"\n")
        if not same:
            raise ValueError(msg)
        return msg
    if action == "audit":
        ok, msg = audit(OUT / "totals.csv")
        write(OUT / "audit.txt", msg+"\n")
        if not ok:
            raise ValueError(msg)
        return msg
    if action == "fault":
        rows = read_csv(OUT / "totals.csv")
        if not audit(OUT / "totals.csv")[0]:
            raise ValueError("Run audit and correct the result first.")
        rows[0]["cents"] = str(int(rows[0]["cents"])+10000)
        rows[1]["cents"] = str(int(rows[1]["cents"])-10000)
        copy = OUT / "fault_copy.csv"
        write_csv(copy,TOTAL,([r[k] for k in TOTAL] for r in rows))
        ok, detail = audit(copy)
        if ok:
            raise ValueError("Undetected control error.")
        total_cents = sum(int(row["cents"]) for row in read_csv(copy))
        msg = f"file=fault_copy.csv | total_cents={total_cents}\n"+detail
        write(OUT / "fault.txt", msg+"\n")
        return msg
    # Reproduce and compare every required evidence file before packing.
    if not (OUT / "repeat.txt").is_file() or not (OUT / "audit.txt").is_file() or not (OUT / "fault.txt").is_file():
        raise ValueError("Complete repeat, audit and fault first.")
    for step in ("repeat","audit","fault"):
        run(step)
    report = (ROOT / "REPORT.txt").read_text(encoding="utf-8-sig").splitlines()
    for field in REPORT_FIELDS:
        if not any(s.startswith(field + ":") and s.partition(":")[2].strip() for s in report):
            raise ValueError("Complete REPORT.txt (" + field + ")")
    names = ["lab.py","REPORT.txt","README.txt", *["data/"+n for n in HASHES],
             *["results/"+n for n in ["config.json", *PRODUCTS,"repeat.txt","audit.txt","fault.txt","fault_copy.csv"]]]
    temp = ROOT / "submission.tmp"
    with ZipFile(temp, "w", ZIP_DEFLATED) as z:
        for n in names:
            z.write(ROOT / n,n)
    temp.replace(ROOT / "BigData15_result.zip")
    return "saved=BigData15_result.zip"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["check","start3","start4","repeat","audit","fault","pack"])
    args = parser.parse_args()
    try:
        if sys.version_info < (3,10):
            raise ValueError("Python 3.10+ required")
        print(run(args.action))
    except (ValueError, OSError, KeyError, csv.Error) as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        sys.exit(1)

