@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto plain
py -3 lab.py check
goto done
:plain
python lab.py check
:done
set "LAB_RC=%ERRORLEVEL%"
if not defined LAB15_BATCH pause
exit /b %LAB_RC%
