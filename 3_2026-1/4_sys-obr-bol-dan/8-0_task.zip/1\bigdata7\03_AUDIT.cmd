@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=py -3"
    goto ready
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=python"
    goto ready
)
echo Python 3.10 or later was not found. Open DOWNLOADS.html.
pause
exit /b 1
:ready
echo RUN: %PY_CMD% lab.py audit
%PY_CMD% lab.py audit
set "LAB_EXIT=%ERRORLEVEL%"
if not "%LAB_EXIT%"=="0" echo ERROR. Save the message and contact your teacher.
pause
exit /b %LAB_EXIT%
