"""Finite local teaching model: reconciliation and versioned replacement, stdlib only."""
from pathlib import Path
from decimal import Decimal
import copy,csv,hashlib,json,sys,zipfile
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'results'; DATA=ROOT/'data/arrivals.csv'
FIELDS=['event_id','event_time','arrival_time','event_type','status','amount']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def dump(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def money(n):return f'{Decimal(n)/100:.2f}'
def sec(t):
 h,m,s=map(int,t.split(':'))
 if not(0<=h<24 and 0<=m<60 and 0<=s<60):raise ValueError('Invalid time')
 return h*3600+m*60+s
def clock(n):return f'{n//3600:02d}:{n%3600//60:02d}'
def win(r):return clock(sec(r['event_time'])//300*300)
def selected(r):return r['event_type']=='purchase' and r['status']=='success'
def cents(r):
 n=Decimal(r['amount'])*100
 if n<0 or n!=n.to_integral_value():raise ValueError('Invalid amount')
 return int(n)
def source():
 if sha(DATA)!=load(ROOT/'source_manifest.json')['sha256']:raise ValueError('Source changed. Use a fresh project.')
 with DATA.open(encoding='utf-8-sig',newline='') as f:
  rd=csv.DictReader(f)
  if rd.fieldnames!=FIELDS:raise ValueError('Unexpected source columns')
  rows=list(rd)
 if len(rows)!=12 or len({r['event_id'] for r in rows})!=12:raise ValueError('Expected 12 unique source events')
 prior=-1
 for r in rows:
  a=sec(r['arrival_time']);e=sec(r['event_time']);cents(r)
  if a<prior or a<e:raise ValueError('Invalid arrival order')
  prior=a
 return rows

def aggregate(rows,keys):
 g={k:{'count':0,'sum_cents':0,'revision':1} for k in keys}
 for r in rows:
  if selected(r):g[win(r)]['count']+=1;g[win(r)]['sum_cents']+=cents(r)
 return g

def replace(state,patch):
 """Own rule: higher revision replaces, equal identical is NOOP, equal different rejects."""
 key=patch['window_start'];value={k:patch[k] for k in ['count','sum_cents','revision']}
 if key not in state:state[key]=value;return 'INSERT'
 old=state[key]
 if value['revision']<old['revision']:return 'REJECT_STALE'
 if value['revision']==old['revision']:
  return 'NOOP_SAME' if value==old else 'REJECT_CONFLICT'
 state[key]=value;return 'REPLACE'

def model():
 rows=source();keys=sorted({win(r) for r in rows});accepted=[];late=[];filtered=[];trace=[];maximum=None
 for r in rows:
  t=sec(r['event_time']);end=t//300*300+300;before=None if maximum is None else maximum-120
  decision='FILTERED'
  if selected(r):
   if before is not None and end<=before:decision='LATE';late.append(r)
   else:decision='ACCEPT';accepted.append(r)
  else:filtered.append(r)
  trace.append({'event_id':r['event_id'],'window_start':win(r),'watermark_before':'NONE' if before is None else clock(before),'decision':decision})
  maximum=t if maximum is None else max(maximum,t)
 base=aggregate(accepted,keys);ref=aggregate(rows,keys)
 audit=[{'window_start':k,'before_count':base[k]['count'],'reference_count':ref[k]['count'],'delta_count':ref[k]['count']-base[k]['count'],'before_cents':base[k]['sum_cents'],'reference_cents':ref[k]['sum_cents'],'delta_cents':ref[k]['sum_cents']-base[k]['sum_cents']} for k in keys]
 patches=[{'window_start':r['window_start'],'count':r['reference_count'],'sum_cents':r['reference_cents'],'revision':2} for r in audit if r['delta_count'] or r['delta_cents']]
 first=copy.deepcopy(base);second=copy.deepcopy(base)
 for r in late:
  for g,times in [(first,1),(second,2)]:g[win(r)]['count']+=times;g[win(r)]['sum_cents']+=times*cents(r)
 fixed=copy.deepcopy(base)
 for p in patches:replace(fixed,p)
 return dict(rows=rows,base=base,ref=ref,audit=audit,patches=patches,late=late,filtered=filtered,trace=trace,first=first,second=second,fixed=fixed)

def total(g):return sum(v['count'] for v in g.values()),sum(v['sum_cents'] for v in g.values())
def emit(name,lines):
 OUT.mkdir(exist_ok=True);t='\n'.join(lines)+'\n';(OUT/(name+'.txt')).write_text(t,encoding='utf-8-sig');print(t,end='')
def write_csv(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def rows_of(g):return [{'window_start':k,'window_end':clock(sec(k+':00')+300),'count':v['count'],'amount':money(v['sum_cents']),'revision':v['revision']} for k,v in g.items()]
def require(name,expected):
 p=OUT/name
 if not p.exists() or load(p)!=expected:raise ValueError('Missing or changed '+name+'. Run the previous steps.')
def table(g):return [f"{k} | {v['count']} | {money(v['sum_cents'])} | r{v['revision']}" for k,v in g.items()]

def snapshot():
 m=model();dump(OUT/'preliminary.json',m['base']);write_csv('preliminary.csv',rows_of(m['base']));write_csv('late.csv',m['late']);write_csv('trace.csv',m['trace'])
 emit('01_snapshot',['DELAY=2 minutes; selected accepted=9','WINDOW | COUNT | AMOUNT | REVISION',*table(m['base']),'TOTAL=4800.00; LATE=E009 / 700.00','FILTERED=E004,E006; source order unchanged.'])
def reference():
 m=model();require('preliminary.json',m['base']);dump(OUT/'reference.json',m['ref']);write_csv('reference.csv',rows_of(m['ref']))
 emit('02_reference',['BATCH REFERENCE: all 12 source rows; selected purchases=10',*table(m['ref']),'TOTAL=5500.00','Finite-source reference; this does not close streaming windows.'])
def audit():
 m=model();require('preliminary.json',m['base']);require('reference.json',m['ref']);dump(OUT/'audit.json',m['audit']);write_csv('audit.csv',m['audit'])
 emit('03_audit',['WINDOW | BEFORE | REFERENCE | DIFFERENCE',*[f"{r['window_start']} | {money(r['before_cents'])} | {money(r['reference_cents'])} | {money(r['delta_cents'])}" for r in m['audit']],'MISMATCH: 10:05; missing count=1; missing amount=700.00','CAUSE: E009 was LATE under the previous rule.'])
def naive():
 m=model();require('audit.json',m['audit']);dump(OUT/'naive_once.json',m['first']);dump(OUT/'naive_twice.json',m['second']);write_csv('naive_once.csv',rows_of(m['first']));write_csv('naive_twice.csv',rows_of(m['second']))
 emit('04_naive',['ADD THE SAME LATE PURCHASE TWICE','BEFORE: total=4800.00; window 10:05=800.00','FIRST: total=5500.00; window 10:05=1500.00','SECOND: total=6200.00; window 10:05=2200.00','OVERCOUNT=700.00; selected count=11 instead of 10','This demonstration does not change the versioned state.'])
def patch():
 m=model();require('audit.json',m['audit']);dump(OUT/'patch.json',m['patches']);write_csv('patch.csv',m['patches'])
 emit('05_patch',['REPLACEMENT PATCH','KEY=10:05; window=[10:05,10:10)','COUNT=3; AMOUNT=1500.00; REVISION=2','Payload contains the FULL corrected window value, not +700.','Only this window is changed. Other rows retain revision 1.'])
def apply():
 m=model();require('patch.json',m['patches']);require('preliminary.json',m['base'])
 state=copy.deepcopy(m['base'])
 if (OUT/'state.json').exists():
  require('state.json',m['fixed']);print('NOOP: state already corrected. Continue with repeat.');return
 actions=[replace(state,p) for p in m['patches']]
 dump(OUT/'state.json',state);dump(OUT/'after_first.json',state);write_csv('after_first.csv',rows_of(state))
 emit('06_apply',['KEY=10:05; ACTION='+','.join(actions),'BEFORE: count=2; amount=800.00; revision=1','AFTER: count=3; amount=1500.00; revision=2','TOTAL=5500.00; selected count=10','Saved results/state.json for the next command.'])
def repeat():
 m=model();require('state.json',m['fixed']);require('after_first.json',m['fixed']);require('patch.json',m['patches']);state=load(OUT/'state.json');old=copy.deepcopy(state)
 actions=[replace(state,p) for p in m['patches']]
 if state!=old:raise ValueError('Replay changed the state')
 dump(OUT/'after_repeat.json',state);write_csv('after_repeat.csv',rows_of(state))
 emit('07_repeat',['READ: saved results/state.json','KEY=10:05; ACTION='+','.join(actions),'TOTAL_BEFORE=5500.00; TOTAL_AFTER=5500.00','UNCHANGED=True; count=10; window revision=2','Same correction repeated on the persisted state.'])
def guards():
 m=model();require('after_repeat.json',m['fixed']);require('state.json',m['fixed']);state=load(OUT/'state.json');old=copy.deepcopy(state)
 stale={'window_start':'10:05',**m['base']['10:05']};conflict={**m['patches'][0],'sum_cents':160000}
 decisions=[replace(state,stale),replace(state,conflict)]
 if state!=old:raise ValueError('Rejected patch modified the state')
 obj={'decisions':decisions,'unchanged':state==old,'sum_cents':total(state)[1]};dump(OUT/'guards.json',obj)
 emit('08_guards',['OLDER revision=1: '+decisions[0],'SAME revision=2 but amount=1600.00: '+decisions[1],'STATE_UNCHANGED=True; TOTAL=5500.00','Expected refusals; never overwrite a conflicting same revision.'])
def compare():
 m=model()
 for name,obj in [('preliminary.json',m['base']),('reference.json',m['ref']),('audit.json',m['audit']),('naive_once.json',m['first']),('naive_twice.json',m['second']),('patch.json',m['patches']),('after_first.json',m['fixed']),('after_repeat.json',m['fixed']),('state.json',m['fixed']),('guards.json',{'decisions':['REJECT_STALE','REJECT_CONFLICT'],'unchanged':True,'sum_cents':550000})]:require(name,obj)
 # Validate CSV observations too, so editing a table cannot silently pass packaging.
 expected={'preliminary.csv':rows_of(m['base']),'reference.csv':rows_of(m['ref']),'audit.csv':m['audit'],'late.csv':m['late'],'trace.csv':m['trace'],'naive_once.csv':rows_of(m['first']),'naive_twice.csv':rows_of(m['second']),'patch.csv':m['patches'],'after_first.csv':rows_of(m['fixed']),'after_repeat.csv':rows_of(m['fixed'])}
 for name,rows in expected.items():
  p=OUT/name
  if not p.exists():raise ValueError('Missing '+name)
  with p.open(encoding='utf-8-sig',newline='') as f:actual=list(csv.DictReader(f))
  if actual!=[{k:str(v) for k,v in r.items()} for r in rows]:raise ValueError('Changed '+name)
 for k in m['ref']:
  if any(m['fixed'][k][f]!=m['ref'][k][f] for f in ['count','sum_cents']):raise ValueError('Per-window mismatch')
 emit('09_compare',['PASS: every corrected window matches batch count and amount.','PASS: replay on saved state leaves 5500.00 unchanged.','PASS: stale and conflicting corrections leave state unchanged.','NAIVE SECOND=6200.00; VERSIONED REPEAT=5500.00','This finite sequential test is not an exactly-once guarantee.'])
def pack():
 compare()
 for stem in ['01_snapshot','02_reference','03_audit','04_naive','05_patch','06_apply','07_repeat','08_guards','09_compare']:
  if not (OUT/(stem+'.txt')).is_file():raise ValueError('Complete '+stem)
 report=(ROOT/'REPORT.txt').read_text(encoding='utf-8-sig')
 if '[заполнить]' in report or len(report.strip())<300:raise ValueError('Fill REPORT.txt and save UTF-8')
 target=ROOT/'submission/BigData7_result.zip';target.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f in [ROOT/'REPORT.txt',ROOT/'source_manifest.json',ROOT/'lab.py',DATA,*sorted(OUT.glob('*'))]:
   if f.is_file() and f.suffix in ['.txt','.csv','.json','.py']:z.write(f,f.relative_to(ROOT))
 print('READY: submission/BigData7_result.zip')

if __name__=='__main__':
 commands={'check':lambda:print('Python OK; arrivals='+str(len(source()))+'; stdlib only'),'snapshot':snapshot,'reference':reference,'audit':audit,'naive':naive,'patch':patch,'apply':apply,'repeat':repeat,'guards':guards,'compare':compare,'pack':pack}
 try:
  if sys.version_info<(3,10):raise ValueError('Python 3.10 or later is required')
  name=sys.argv[1] if len(sys.argv)>1 else ''
  if name not in commands:raise ValueError('Use: '+', '.join(commands))
  commands[name]()
 except (ValueError,OSError,KeyError,TypeError) as e:print('ERROR: '+str(e));sys.exit(1)
