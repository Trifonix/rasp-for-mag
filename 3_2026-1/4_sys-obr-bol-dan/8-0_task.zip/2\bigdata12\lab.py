"""Практическая работа 12. Локальный аудит конечного учебного набора."""
from pathlib import Path
import argparse, csv, json, hashlib, re, sys, zipfile
from collections import Counter
from decimal import Decimal
ROOT=Path(__file__).resolve().parent
FIELDS=['window_start','count','sum_cents','revision']
CASES=['clean','missing','duplicate','balanced','stale','invalid','foreign']
CHECKS=['schema','unique','coverage','totals','values','revision','source']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def readj(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def savej(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def source():
 p=ROOT/'data/arrivals.csv';m=readj(ROOT/'source_manifest.json')
 if sha(p)!=m['sha256']: raise ValueError('Source changed. Extract a fresh project; keep your old work.')
 with p.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 return rows,m

def reference():
 rows,_=source();groups={}
 for r in rows:
  if (r['event_type'],r['status'])!=('purchase','success'):continue
  h,m,_=map(int,r['event_time'].split(':'));k=f'{h:02d}:{m//5*5:02d}'
  g=groups.setdefault(k,{'window_start':k,'count':0,'sum_cents':0,'revision':2 if k=='10:05' else 1})
  g['count']+=1;g['sum_cents']+=int(Decimal(r['amount'])*100)
 return groups

def inspect(name):
 _,manifest=source();ref=reference();p=ROOT/'cases'/f'{name}.csv';meta=readj(p.with_suffix('.json'))
 with p.open(encoding='utf-8-sig',newline='') as f:
  reader=csv.DictReader(f);header=reader.fieldnames;raw=list(reader)
 valid=header==FIELDS;rows=[];details=[]
 for n,r in enumerate(raw,2):
  try:
   assert None not in r and set(r)==set(FIELDS)
   assert re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]',r['window_start']) and int(r['window_start'][3:])%5==0
   assert all(re.fullmatch(r'\d+',r[x] or '') for x in FIELDS[1:])
   v={k:(r[k] if k=='window_start' else int(r[k])) for k in FIELDS}
   assert v['revision']>=1
   rows.append(v)
  except (AssertionError,TypeError,KeyError):
   valid=False;details.append(f'INVALID_ROW line={n}')
 keys=[r.get('window_start') for r in raw];counts=Counter(keys)
 duplicates=sorted(str(k) for k,n in counts.items() if n>1)
 missing=sorted(set(ref)-set(keys));extra=sorted(str(x) for x in set(keys)-set(ref))
 result={'schema':'PASS' if valid else 'FAIL','unique':'FAIL' if duplicates else 'PASS','coverage':'FAIL' if missing or extra else 'PASS'}
 total_count=sum(r['count'] for r in rows) if valid else None
 total_cents=sum(r['sum_cents'] for r in rows) if valid else None
 result['totals']=('PASS' if (total_count,total_cents)==(10,550000) else 'FAIL') if valid else 'SKIP'
 unique=not duplicates
 if valid and unique:
  indexed={r['window_start']:r for r in rows}
  bad=[k for k in ref if k not in indexed or any(indexed[k][f]!=ref[k][f] for f in ['count','sum_cents'])]
  rev=[k for k in ref if k not in indexed or indexed[k]['revision']!=ref[k]['revision']]
  result['values']='FAIL' if bad or extra else 'PASS';result['revision']='FAIL' if rev or extra else 'PASS'
  details += ['VALUE_MISMATCH '+k for k in bad]+['REVISION_MISMATCH '+k for k in rev]
 else: result['values']=result['revision']='SKIP'
 result['source']='PASS' if meta.get('source_sha256')==manifest['sha256'] else 'FAIL'
 details += ['DUPLICATE '+k for k in duplicates]+['MISSING '+k for k in missing]+['EXTRA '+k for k in extra]
 if result['source']=='FAIL':details.append('SOURCE_HASH_MISMATCH')
 decision='ALLOW' if all(v=='PASS' for v in result.values()) else 'BLOCK'
 return {'case':name,'rows':len(raw),'total_count':total_count,'total_cents':total_cents,'checks':result,'details':details,'decision':decision,'csv_sha256':sha(p),'meta_sha256':sha(p.with_suffix('.json'))}

def display(a):
 print('CASE='+a['case']+' ROWS='+str(a['rows']))
 if a['total_cents'] is None: print('COUNT=N/A AMOUNT=N/A')
 else: print(f"COUNT={a['total_count']} AMOUNT={a['total_cents']/100:.2f}")
 for k,v in a['checks'].items():print(k.upper()+'='+v)
 print('PUBLISH='+a['decision'])
 for d in a['details']: print(d)

def audit(name):
 a=inspect(name);savej(ROOT/'results'/f'{name}.json',a);display(a)

def summary():
 print('CASE       SC UN CV TO VA RE SO DECISION')
 for name in CASES+['fixed']:
  p=ROOT/'results'/f'{name}.json'
  if not p.exists(): print(name+' NOT_RUN');continue
  a=readj(p)
  if a!=inspect(name):raise ValueError('Stale audit for '+name+'. Run audit again.')
  print(f"{name:<10} "+'  '.join({'PASS':'P','FAIL':'F','SKIP':'-'}[a['checks'][k]] for k in CHECKS)+'  '+a['decision'])
 print('P=PASS F=FAIL -=SKIP; no automatic grade')

def pack():
 source()
 for n in CASES+['fixed']:
  p=ROOT/'results'/f'{n}.json'
  if not p.exists() or readj(p)!=inspect(n):raise ValueError('Missing or stale audit: '+n)
 if inspect('fixed')['decision']!='ALLOW':raise ValueError('Fixed table is not ready: audit fixed must ALLOW')
 report=(ROOT/'REPORT.txt').read_text(encoding='utf-8-sig')
 if '[заполнить]' in report or len(report.strip())<300:raise ValueError('Fill REPORT.txt before packing')
 out=ROOT/'submission/BigData12_result.zip';out.parent.mkdir(exist_ok=True)
 paths=[ROOT/'REPORT.txt',ROOT/'source_manifest.json']+list((ROOT/'data').glob('*'))+list((ROOT/'cases').glob('*'))+list((ROOT/'results').glob('*.json'))
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for p in paths:z.write(p,p.relative_to(ROOT))
 print('SAVED submission/BigData12_result.zip')
 print('Report completeness and explanations are graded by the teacher.')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('action',choices=['check','reference','audit','summary','pack']);parser.add_argument('case',nargs='?',choices=CASES+['fixed']);a=parser.parse_args()
 if sys.version_info<(3,10):raise ValueError('Python 3.10+ required')
 if a.action=='check':
  rows,_=source();print('Python 3.10+: OK\nSOURCE_SHA256=PASS\nEVENTS='+str(len(rows))+'\nCASES=7 + fixed\nINPUT: Windows Command Prompt (cmd)')
 elif a.action=='reference':
  print('WINDOW COUNT SUM_CENTS REVISION')
  for g in reference().values():print(f"{g['window_start']}  {g['count']}     {g['sum_cents']}    {g['revision']}")
  print('TOTAL_COUNT=10 TOTAL_AMOUNT=5500.00');savej(ROOT/'results/reference.json',reference())
 elif a.action=='audit':
  if a.case is None:raise ValueError('Specify case, for example: audit clean')
  audit(a.case)
 elif a.action=='summary':summary()
 else:pack()
if __name__=='__main__':
 try:main()
 except (ValueError,OSError,KeyError,csv.Error,json.JSONDecodeError) as e:print('ERROR: '+str(e));sys.exit(1)
