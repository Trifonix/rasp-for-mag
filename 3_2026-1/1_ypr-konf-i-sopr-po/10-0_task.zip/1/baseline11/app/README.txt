Training baseline 1.0.0
Expected interval=60
Run from any folder: bash PATH/check.sh
