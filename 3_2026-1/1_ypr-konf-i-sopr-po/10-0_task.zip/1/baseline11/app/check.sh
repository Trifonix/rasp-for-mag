#!/usr/bin/env bash
set -u
base=$(cd -- "$(dirname -- "$0")" && pwd) || exit 2
for f in config.txt VERSION.txt README.txt; do
 if [ ! -f "$base/$f" ]; then echo "CHECK FAIL missing $f"; exit 1; fi
done
if [ "$(cat "$base/config.txt")" != "interval=60" ]; then echo "CHECK FAIL interval"; exit 1; fi
if [ "$(cat "$base/VERSION.txt")" != "1.0.0" ]; then echo "CHECK FAIL version"; exit 1; fi
echo "CHECK PASS"
