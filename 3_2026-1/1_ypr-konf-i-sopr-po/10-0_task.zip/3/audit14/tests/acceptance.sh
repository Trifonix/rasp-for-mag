#!/usr/bin/env bash
set -u
app=${1:?usage: bash tests/acceptance.sh PATH_TO_APP}
fail=0
check() { if [ "$1" -eq 0 ]; then echo "TEST PASS $2"; else echo "TEST FAIL $2"; fail=1; fi; }
test -f "$app/check.sh" -a -f "$app/config.txt" -a -f "$app/VERSION.txt" -a -f "$app/README.txt"
check "$?" files
if [ "$(cat "$app/VERSION.txt")" = "1.1.1" ]; then code=0; else code=1; fi
check "$code" version
grep -Fxq 'Allowed interval: 10..60 seconds' "$app/README.txt"
check "$?" documentation
bash "$app/check.sh" > /dev/null 2>&1
check "$?" interval30
temp=$(mktemp -d "${TMPDIR:-/tmp}/audit14.XXXXXX") || exit 2
cp -R "$app/." "$temp/" || exit 2
printf 'interval=0\n' > "$temp/config.txt"
bash "$temp/check.sh" > "$temp/result.txt" 2>&1
code=$?
if [ "$code" -eq 1 ] && grep -Fxq 'CHECK FAIL range' "$temp/result.txt"; then code=0; else code=1; fi
check "$code" interval0
rm -rf -- "$temp"
exit "$fail"
